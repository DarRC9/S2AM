﻿
namespace AppDraft_WookieJoy
{
    partial class MainScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.roundedPanel10 = new RoundedPanel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.roundedPanel1 = new RoundedPanel();
            this.Option3Label = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.roundedPanel5 = new RoundedPanel();
            this.Option2Label = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.roundedPanel2 = new RoundedPanel();
            this.Option4Label = new System.Windows.Forms.Label();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.roundedPanel9 = new RoundedPanel();
            this.roundedPanel8 = new RoundedPanel();
            this.roundedPanel7 = new RoundedPanel();
            this.roundedPanel4 = new RoundedPanel();
            this.roundedPanel3 = new RoundedPanel();
            this.Option1Btn = new RoundButton();
            this.roundedPanel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.roundedPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.roundedPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.roundedPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            this.SuspendLayout();
            // 
            // roundedPanel10
            // 
            this.roundedPanel10.BackColor = System.Drawing.Color.White;
            this.roundedPanel10.Controls.Add(this.Option1Btn);
            this.roundedPanel10.Controls.Add(this.pictureBox1);
            this.roundedPanel10.Controls.Add(this.roundedPanel1);
            this.roundedPanel10.Controls.Add(this.roundedPanel5);
            this.roundedPanel10.Controls.Add(this.roundedPanel2);
            this.roundedPanel10.Location = new System.Drawing.Point(-5, -4);
            this.roundedPanel10.Name = "roundedPanel10";
            this.roundedPanel10.Size = new System.Drawing.Size(270, 796);
            this.roundedPanel10.TabIndex = 15;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::AppDraft_WookieJoy.Properties.Resources.wookiejoybrown;
            this.pictureBox1.Location = new System.Drawing.Point(72, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(121, 117);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 14;
            this.pictureBox1.TabStop = false;
            // 
            // roundedPanel1
            // 
            this.roundedPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(39)))), ((int)(((byte)(10)))));
            this.roundedPanel1.Controls.Add(this.Option3Label);
            this.roundedPanel1.Controls.Add(this.pictureBox3);
            this.roundedPanel1.Location = new System.Drawing.Point(54, 455);
            this.roundedPanel1.Name = "roundedPanel1";
            this.roundedPanel1.Size = new System.Drawing.Size(200, 100);
            this.roundedPanel1.TabIndex = 6;
            // 
            // Option3Label
            // 
            this.Option3Label.AutoSize = true;
            this.Option3Label.Font = new System.Drawing.Font("OCR A Extended", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Option3Label.ForeColor = System.Drawing.Color.White;
            this.Option3Label.Location = new System.Drawing.Point(99, 41);
            this.Option3Label.Name = "Option3Label";
            this.Option3Label.Size = new System.Drawing.Size(101, 23);
            this.Option3Label.TabIndex = 2;
            this.Option3Label.Text = "Option3";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Location = new System.Drawing.Point(10, 12);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(83, 75);
            this.pictureBox3.TabIndex = 1;
            this.pictureBox3.TabStop = false;
            // 
            // roundedPanel5
            // 
            this.roundedPanel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(39)))), ((int)(((byte)(10)))));
            this.roundedPanel5.Controls.Add(this.Option2Label);
            this.roundedPanel5.Controls.Add(this.pictureBox6);
            this.roundedPanel5.Location = new System.Drawing.Point(54, 300);
            this.roundedPanel5.Name = "roundedPanel5";
            this.roundedPanel5.Size = new System.Drawing.Size(200, 100);
            this.roundedPanel5.TabIndex = 9;
            // 
            // Option2Label
            // 
            this.Option2Label.AutoSize = true;
            this.Option2Label.Font = new System.Drawing.Font("OCR A Extended", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Option2Label.ForeColor = System.Drawing.Color.White;
            this.Option2Label.Location = new System.Drawing.Point(99, 41);
            this.Option2Label.Name = "Option2Label";
            this.Option2Label.Size = new System.Drawing.Size(101, 23);
            this.Option2Label.TabIndex = 2;
            this.Option2Label.Text = "Option2";
            // 
            // pictureBox6
            // 
            this.pictureBox6.Location = new System.Drawing.Point(10, 12);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(83, 75);
            this.pictureBox6.TabIndex = 1;
            this.pictureBox6.TabStop = false;
            // 
            // roundedPanel2
            // 
            this.roundedPanel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(39)))), ((int)(((byte)(10)))));
            this.roundedPanel2.Controls.Add(this.Option4Label);
            this.roundedPanel2.Controls.Add(this.pictureBox8);
            this.roundedPanel2.Location = new System.Drawing.Point(54, 608);
            this.roundedPanel2.Name = "roundedPanel2";
            this.roundedPanel2.Size = new System.Drawing.Size(200, 100);
            this.roundedPanel2.TabIndex = 7;
            // 
            // Option4Label
            // 
            this.Option4Label.AutoSize = true;
            this.Option4Label.Font = new System.Drawing.Font("OCR A Extended", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Option4Label.ForeColor = System.Drawing.Color.White;
            this.Option4Label.Location = new System.Drawing.Point(99, 41);
            this.Option4Label.Name = "Option4Label";
            this.Option4Label.Size = new System.Drawing.Size(101, 23);
            this.Option4Label.TabIndex = 2;
            this.Option4Label.Text = "Option4";
            // 
            // pictureBox8
            // 
            this.pictureBox8.Location = new System.Drawing.Point(10, 12);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(83, 75);
            this.pictureBox8.TabIndex = 1;
            this.pictureBox8.TabStop = false;
            // 
            // roundedPanel9
            // 
            this.roundedPanel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(39)))), ((int)(((byte)(10)))));
            this.roundedPanel9.Location = new System.Drawing.Point(389, 367);
            this.roundedPanel9.Name = "roundedPanel9";
            this.roundedPanel9.Size = new System.Drawing.Size(51, 47);
            this.roundedPanel9.TabIndex = 13;
            // 
            // roundedPanel8
            // 
            this.roundedPanel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(39)))), ((int)(((byte)(10)))));
            this.roundedPanel8.Location = new System.Drawing.Point(476, 134);
            this.roundedPanel8.Name = "roundedPanel8";
            this.roundedPanel8.Size = new System.Drawing.Size(51, 47);
            this.roundedPanel8.TabIndex = 13;
            // 
            // roundedPanel7
            // 
            this.roundedPanel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(39)))), ((int)(((byte)(10)))));
            this.roundedPanel7.Location = new System.Drawing.Point(422, 251);
            this.roundedPanel7.Name = "roundedPanel7";
            this.roundedPanel7.Size = new System.Drawing.Size(51, 47);
            this.roundedPanel7.TabIndex = 13;
            // 
            // roundedPanel4
            // 
            this.roundedPanel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(39)))), ((int)(((byte)(10)))));
            this.roundedPanel4.Location = new System.Drawing.Point(422, 483);
            this.roundedPanel4.Name = "roundedPanel4";
            this.roundedPanel4.Size = new System.Drawing.Size(51, 47);
            this.roundedPanel4.TabIndex = 13;
            // 
            // roundedPanel3
            // 
            this.roundedPanel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(39)))), ((int)(((byte)(10)))));
            this.roundedPanel3.Location = new System.Drawing.Point(476, 617);
            this.roundedPanel3.Name = "roundedPanel3";
            this.roundedPanel3.Size = new System.Drawing.Size(51, 47);
            this.roundedPanel3.TabIndex = 12;
            // 
            // Option1Btn
            // 
            this.Option1Btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(39)))), ((int)(((byte)(10)))));
            this.Option1Btn.Font = new System.Drawing.Font("OCR A Extended", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Option1Btn.ForeColor = System.Drawing.Color.White;
            this.Option1Btn.Location = new System.Drawing.Point(54, 164);
            this.Option1Btn.Name = "Option1Btn";
            this.Option1Btn.Size = new System.Drawing.Size(156, 99);
            this.Option1Btn.TabIndex = 16;
            this.Option1Btn.Text = "Option 1";
            this.Option1Btn.UseVisualStyleBackColor = false;
            this.Option1Btn.Click += new System.EventHandler(this.roundButton1_Click);
            // 
            // MainScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(246)))), ((int)(((byte)(127)))));
            this.ClientSize = new System.Drawing.Size(1386, 788);
            this.Controls.Add(this.roundedPanel10);
            this.Controls.Add(this.roundedPanel9);
            this.Controls.Add(this.roundedPanel8);
            this.Controls.Add(this.roundedPanel7);
            this.Controls.Add(this.roundedPanel4);
            this.Controls.Add(this.roundedPanel3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "MainScreen";
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.roundedPanel10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.roundedPanel1.ResumeLayout(false);
            this.roundedPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.roundedPanel5.ResumeLayout(false);
            this.roundedPanel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.roundedPanel2.ResumeLayout(false);
            this.roundedPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label Option3Label;
        private System.Windows.Forms.PictureBox pictureBox3;
        private RoundedPanel roundedPanel1;
        private RoundedPanel roundedPanel2;
        private System.Windows.Forms.Label Option4Label;
        private System.Windows.Forms.PictureBox pictureBox8;
        private RoundedPanel roundedPanel5;
        private System.Windows.Forms.Label Option2Label;
        private System.Windows.Forms.PictureBox pictureBox6;
        private RoundedPanel roundedPanel3;
        private RoundedPanel roundedPanel4;
        private RoundedPanel roundedPanel7;
        private RoundedPanel roundedPanel8;
        private RoundedPanel roundedPanel9;
        private System.Windows.Forms.PictureBox pictureBox1;
        private RoundedPanel roundedPanel10;
        private RoundButton Option1Btn;
    }
}