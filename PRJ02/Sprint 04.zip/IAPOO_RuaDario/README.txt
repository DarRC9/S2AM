Documentation located in:
DocumentacioTecnica-->Help-->html