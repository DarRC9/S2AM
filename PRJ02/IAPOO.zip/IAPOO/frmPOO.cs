﻿using System.Windows.Forms;

namespace PCBRecuperacio
{
    public partial class frmPOO : Form
    {
        public frmPOO()
        {
            InitializeComponent();
        }
    }
}
