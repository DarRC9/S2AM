﻿
namespace REGEX_PRACTICE
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.verificationPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.TelefonTxt = new System.Windows.Forms.TextBox();
            this.CodiTxt = new System.Windows.Forms.TextBox();
            this.EmailTxt = new System.Windows.Forms.TextBox();
            this.Verificar1Btn = new System.Windows.Forms.Button();
            this.Verificar2Btn = new System.Windows.Forms.Button();
            this.Verificar3Btn = new System.Windows.Forms.Button();
            this.verificationPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.verificationPanel3 = new System.Windows.Forms.FlowLayoutPanel();
            this.TelefonRgxTxt = new System.Windows.Forms.TextBox();
            this.EmailRgxTxt = new System.Windows.Forms.TextBox();
            this.CodiRgxTxt = new System.Windows.Forms.TextBox();
            this.TelLbl = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.StarWarsLbl = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // verificationPanel1
            // 
            this.verificationPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.verificationPanel1.Location = new System.Drawing.Point(665, 128);
            this.verificationPanel1.Name = "verificationPanel1";
            this.verificationPanel1.Size = new System.Drawing.Size(40, 37);
            this.verificationPanel1.TabIndex = 0;
            // 
            // TelefonTxt
            // 
            this.TelefonTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TelefonTxt.Location = new System.Drawing.Point(170, 136);
            this.TelefonTxt.Name = "TelefonTxt";
            this.TelefonTxt.Size = new System.Drawing.Size(428, 30);
            this.TelefonTxt.TabIndex = 1;
            // 
            // CodiTxt
            // 
            this.CodiTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CodiTxt.Location = new System.Drawing.Point(170, 330);
            this.CodiTxt.Name = "CodiTxt";
            this.CodiTxt.Size = new System.Drawing.Size(428, 30);
            this.CodiTxt.TabIndex = 2;
            // 
            // EmailTxt
            // 
            this.EmailTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmailTxt.Location = new System.Drawing.Point(170, 239);
            this.EmailTxt.Name = "EmailTxt";
            this.EmailTxt.Size = new System.Drawing.Size(428, 30);
            this.EmailTxt.TabIndex = 3;
            // 
            // Verificar1Btn
            // 
            this.Verificar1Btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Verificar1Btn.Location = new System.Drawing.Point(762, 134);
            this.Verificar1Btn.Name = "Verificar1Btn";
            this.Verificar1Btn.Size = new System.Drawing.Size(134, 30);
            this.Verificar1Btn.TabIndex = 4;
            this.Verificar1Btn.Text = "Verificar";
            this.Verificar1Btn.UseVisualStyleBackColor = true;
            this.Verificar1Btn.Click += new System.EventHandler(this.Verificar1Btn_Click);
            // 
            // Verificar2Btn
            // 
            this.Verificar2Btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Verificar2Btn.Location = new System.Drawing.Point(762, 234);
            this.Verificar2Btn.Name = "Verificar2Btn";
            this.Verificar2Btn.Size = new System.Drawing.Size(134, 30);
            this.Verificar2Btn.TabIndex = 5;
            this.Verificar2Btn.Text = "Verificar";
            this.Verificar2Btn.UseVisualStyleBackColor = true;
            this.Verificar2Btn.Click += new System.EventHandler(this.Verificar2Btn_Click);
            // 
            // Verificar3Btn
            // 
            this.Verificar3Btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Verificar3Btn.Location = new System.Drawing.Point(762, 323);
            this.Verificar3Btn.Name = "Verificar3Btn";
            this.Verificar3Btn.Size = new System.Drawing.Size(134, 37);
            this.Verificar3Btn.TabIndex = 6;
            this.Verificar3Btn.Text = "Verificar";
            this.Verificar3Btn.UseVisualStyleBackColor = true;
            this.Verificar3Btn.Click += new System.EventHandler(this.Verificar3Btn_Click);
            // 
            // verificationPanel2
            // 
            this.verificationPanel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.verificationPanel2.Location = new System.Drawing.Point(665, 231);
            this.verificationPanel2.Name = "verificationPanel2";
            this.verificationPanel2.Size = new System.Drawing.Size(40, 37);
            this.verificationPanel2.TabIndex = 1;
            // 
            // verificationPanel3
            // 
            this.verificationPanel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.verificationPanel3.Location = new System.Drawing.Point(665, 323);
            this.verificationPanel3.Name = "verificationPanel3";
            this.verificationPanel3.Size = new System.Drawing.Size(40, 37);
            this.verificationPanel3.TabIndex = 1;
            // 
            // TelefonRgxTxt
            // 
            this.TelefonRgxTxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.TelefonRgxTxt.Enabled = false;
            this.TelefonRgxTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TelefonRgxTxt.Location = new System.Drawing.Point(947, 132);
            this.TelefonRgxTxt.Name = "TelefonRgxTxt";
            this.TelefonRgxTxt.Size = new System.Drawing.Size(428, 30);
            this.TelefonRgxTxt.TabIndex = 7;
            this.TelefonRgxTxt.Text = "^\\(?\\+\\d{1,3}\\)?\\-\\d{3}\\.\\d{2}\\.\\d{2}\\.\\d{2}$";
            // 
            // EmailRgxTxt
            // 
            this.EmailRgxTxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.EmailRgxTxt.Enabled = false;
            this.EmailRgxTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmailRgxTxt.Location = new System.Drawing.Point(947, 232);
            this.EmailRgxTxt.Name = "EmailRgxTxt";
            this.EmailRgxTxt.Size = new System.Drawing.Size(428, 30);
            this.EmailRgxTxt.TabIndex = 8;
            this.EmailRgxTxt.Text = "^[^\\d]\\w*\\.\\w+\\@[^\\d]\\w+\\.[a-zA-Z]{2,3}$";
            // 
            // CodiRgxTxt
            // 
            this.CodiRgxTxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.CodiRgxTxt.Enabled = false;
            this.CodiRgxTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CodiRgxTxt.Location = new System.Drawing.Point(947, 326);
            this.CodiRgxTxt.Name = "CodiRgxTxt";
            this.CodiRgxTxt.Size = new System.Drawing.Size(428, 30);
            this.CodiRgxTxt.TabIndex = 9;
            this.CodiRgxTxt.Text = "^[A-Z]{4}\\-\\d{3}\\/[13579][AEIOU]$";
            // 
            // TelLbl
            // 
            this.TelLbl.AutoSize = true;
            this.TelLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TelLbl.Location = new System.Drawing.Point(59, 128);
            this.TelLbl.Name = "TelLbl";
            this.TelLbl.Size = new System.Drawing.Size(78, 50);
            this.TelLbl.TabIndex = 10;
            this.TelLbl.Text = "Telefon\r\n Mobil";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(63, 237);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 25);
            this.label2.TabIndex = 11;
            this.label2.Text = "Email";
            // 
            // StarWarsLbl
            // 
            this.StarWarsLbl.AutoSize = true;
            this.StarWarsLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StarWarsLbl.Location = new System.Drawing.Point(59, 333);
            this.StarWarsLbl.Name = "StarWarsLbl";
            this.StarWarsLbl.Size = new System.Drawing.Size(100, 50);
            this.StarWarsLbl.TabIndex = 12;
            this.StarWarsLbl.Text = "Codi \r\nStar Wars";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(59, 405);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(852, 50);
            this.label1.TabIndex = 13;
            this.label1.Text = "Els jocs de prova del codi son diferents a la mostra inicial amb el \"\\\" que en la" +
    " mostra n\'hi ha un \"/\"\r\nHe considerat com valid el \"/\"";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1454, 573);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.StarWarsLbl);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.TelLbl);
            this.Controls.Add(this.CodiRgxTxt);
            this.Controls.Add(this.EmailRgxTxt);
            this.Controls.Add(this.TelefonRgxTxt);
            this.Controls.Add(this.verificationPanel3);
            this.Controls.Add(this.verificationPanel2);
            this.Controls.Add(this.Verificar3Btn);
            this.Controls.Add(this.Verificar2Btn);
            this.Controls.Add(this.Verificar1Btn);
            this.Controls.Add(this.EmailTxt);
            this.Controls.Add(this.CodiTxt);
            this.Controls.Add(this.TelefonTxt);
            this.Controls.Add(this.verificationPanel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel verificationPanel1;
        private System.Windows.Forms.TextBox TelefonTxt;
        private System.Windows.Forms.TextBox CodiTxt;
        private System.Windows.Forms.TextBox EmailTxt;
        private System.Windows.Forms.Button Verificar1Btn;
        private System.Windows.Forms.Button Verificar2Btn;
        private System.Windows.Forms.Button Verificar3Btn;
        private System.Windows.Forms.FlowLayoutPanel verificationPanel2;
        private System.Windows.Forms.FlowLayoutPanel verificationPanel3;
        private System.Windows.Forms.TextBox TelefonRgxTxt;
        private System.Windows.Forms.TextBox EmailRgxTxt;
        private System.Windows.Forms.TextBox CodiRgxTxt;
        private System.Windows.Forms.Label TelLbl;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label StarWarsLbl;
        private System.Windows.Forms.Label label1;
    }
}

