﻿namespace Missatges
{
    public class MissatgeSimple
    {
        public string salutacio()
        {
            string mis = "Benvingut";
            return mis;
        }

        public string comiat()
        {
            string mis = "Adeu, fins aviat";
            return mis;
        }
    }
}
