﻿
namespace frmSpecies
{
    partial class frmSpecies
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TextCodeSpecie = new System.Windows.Forms.TextBox();
            this.TextDescSpecie = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // TextCodeSpecie
            // 
            this.TextCodeSpecie.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextCodeSpecie.Location = new System.Drawing.Point(153, 25);
            this.TextCodeSpecie.Name = "TextCodeSpecie";
            this.TextCodeSpecie.Size = new System.Drawing.Size(336, 27);
            this.TextCodeSpecie.TabIndex = 10;
            this.TextCodeSpecie.Tag = "CodeSpecie";
            // 
            // TextDescSpecie
            // 
            this.TextDescSpecie.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextDescSpecie.Location = new System.Drawing.Point(230, 78);
            this.TextDescSpecie.Name = "TextDescSpecie";
            this.TextDescSpecie.Size = new System.Drawing.Size(336, 27);
            this.TextDescSpecie.TabIndex = 11;
            this.TextDescSpecie.Tag = "DescSpecie";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 20);
            this.label1.TabIndex = 12;
            this.label1.Text = "Specie Code";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(15, 78);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(151, 20);
            this.label2.TabIndex = 13;
            this.label2.Text = "Specie Description";
            // 
            // frmSpecies
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TextDescSpecie);
            this.Controls.Add(this.TextCodeSpecie);
            this.Name = "frmSpecies";
            this.Controls.SetChildIndex(this.TextCodeSpecie, 0);
            this.Controls.SetChildIndex(this.TextDescSpecie, 0);
            this.Controls.SetChildIndex(this.label1, 0);
            this.Controls.SetChildIndex(this.label2, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TextCodeSpecie;
        private System.Windows.Forms.TextBox TextDescSpecie;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}

